// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// // Apni screen import kar lo
// import '../screens/order_history_screen.dart'; // path sahi kar lena
//
// class NotificationService {
//   // Apna navigatorKey mat banao, external se set karenge
//   static GlobalKey<NavigatorState>? _navigatorKey;
//
//   // Ye function main.dart se call karoge key set karne ke liye
//   static void setNavigatorKey(GlobalKey<NavigatorState> key) {
//     _navigatorKey = key;
//   }
//
//   static final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
//   FlutterLocalNotificationsPlugin();
//
//   // Background handler
//   @pragma('vm:entry-point')
//   static Future<void> _firebaseMessagingBackgroundHandler(
//       RemoteMessage message) async {
//     await showNotification(message);
//   }
//
//   static Future<void> init() async {
//     FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
//
//     const AndroidInitializationSettings androidInit =
//     AndroidInitializationSettings('@mipmap/ic_launcher');
//     const DarwinInitializationSettings iosInit = DarwinInitializationSettings();
//
//     const InitializationSettings initSettings = InitializationSettings(
//       android: androidInit,
//       iOS: iosInit,
//     );
//
//     await _flutterLocalNotificationsPlugin.initialize(
//       initSettings,
//       onDidReceiveNotificationResponse: _onNotificationTap,
//       onDidReceiveBackgroundNotificationResponse: _onBackgroundNotificationTap,
//     );
//
//     // Foreground messages
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       showNotification(message);
//     });
//   }
//
//   static Future<void> showNotification(RemoteMessage message) async {
//     const AndroidNotificationDetails androidDetails =
//     AndroidNotificationDetails(
//       'high_importance_channel',
//       'High Importance Notifications',
//       channelDescription: 'Important notifications',
//       importance: Importance.max,
//       priority: Priority.high,
//     );
//
//     const NotificationDetails notificationDetails =
//     NotificationDetails(android: androidDetails);
//
//     String payload = 'order_history'; // ya message.data['screen'] se dynamically
//
//     if (message.data['screen'] == 'order_history') {
//       payload = 'order_history';
//     }
//
//     await _flutterLocalNotificationsPlugin.show(
//       DateTime.now().millisecondsSinceEpoch ~/ 1000,
//       message.notification?.title ?? 'New Notification',
//       message.notification?.body ?? 'You have a new message',
//       notificationDetails,
//       payload: payload,
//     );
//   }
//
//   static void _onNotificationTap(NotificationResponse response) {
//     _handleNavigation(response.payload);
//   }
//
//   @pragma('vm:entry-point')
//   static void _onBackgroundNotificationTap(NotificationResponse response) {
//     _handleNavigation(response.payload);
//   }
//
//   static void _handleNavigation(String? payload) {
//     if (payload == 'order_history' && _navigatorKey?.currentContext != null && _navigatorKey!.currentContext!.mounted) {
//       Navigator.of(_navigatorKey!.currentContext!).push(
//         MaterialPageRoute(builder: (_) =>  OrderHistoryScreen()),
//       );
//     }
//   }
//
//   static void setupInteractedMessage() {
//     FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
//       if (message.data['screen'] == 'order_history') {
//         _handleNavigation('order_history');
//       }
//     });
//   }
//
//   static Future<void> checkInitialMessage() async {
//     RemoteMessage? initialMessage =
//     await FirebaseMessaging.instance.getInitialMessage();
//     if (initialMessage != null && initialMessage.data['screen'] == 'order_history') {
//       _handleNavigation('order_history');
//     }
//
//     final details = await _flutterLocalNotificationsPlugin.getNotificationAppLaunchDetails();
//     if (details != null && details.didNotificationLaunchApp) {
//       _handleNavigation(details.notificationResponse?.payload);
//     }
//   }
// }

// notification_service.dart
/*

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:jkautomed/main.dart'; // global navigator key yahan se import
import '../screens/order_history_screen.dart'; // apna screen import karo

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final _messaging = FirebaseMessaging.instance;
  final _localNotifications = FlutterLocalNotificationsPlugin();

  static const _androidChannel = AndroidNotificationChannel(
    'high_importance_channel',
    'High Importance Notifications',
    description: 'Important notifications',
    importance: Importance.max,
  );

  Future<void> initialize() async {
    // iOS permission
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Foreground notifications dikhane ke liye (Android)
    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // Local notifications initialize
    const initSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettingsIOS = DarwinInitializationSettings();
    const initSettings = InitializationSettings(
      android: initSettingsAndroid,
      iOS: initSettingsIOS,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
    );

    // Android channel create (important!)
    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_androidChannel);

    // Foreground message
    FirebaseMessaging.onMessage.listen(_onForegroundMessage);

    // Background/Terminated → user ne click kiya jab app background mein thi
    FirebaseMessaging.onMessageOpenedApp.listen(_onMessageOpenedApp);

    // Terminated state → app bilkul band thi
    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      _handleMessage(initialMessage);
    }

    // Background handler register (top-level function hona chahiye)
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  // Foreground message aane par local notification dikhao
  Future<void> _onForegroundMessage(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;

    await _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _androidChannel.id,
          _androidChannel.name,
          channelDescription: _androidChannel.description,
          importance: _androidChannel.importance,
          icon: '@mipmap/ic_launcher',
        ),
        iOS: const DarwinNotificationDetails(),
      ),
      payload: message.data['payload'], // ya JSON.encode(message.data)
    );
  }

  // Jab user notification tap kare (background ya terminated se aaya)
  void _onMessageOpenedApp(RemoteMessage message) {
    _handleMessage(message);
  }

  // Local notification tap handler
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    if (response.payload != null) {
      _navigateBasedOnPayload(response.payload!);
    }
  }

  // Common navigation logic
  void _handleMessage(RemoteMessage message) {
    final data = message.data;

    // Yahan apne hisab se logic daal sakte ho
    if (data['screen'] == 'order_history') {
      _navigateToOrderHistory(data['orderId']);
    }
    // aur bhi screens add kar sakte ho
  }

  void _navigateBasedOnPayload(String payload) {
    // agar payload JSON hai to parse karo
    // simple case ke liye
    if (payload.contains('order_history')) {
      _navigateToOrderHistory(null);
    }
  }

  void _navigateToOrderHistory(String? orderId) {
    final context = ajugnuGlobalContext.currentContext;
    if (context == null || !context.mounted) return;

    // Safe navigation
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => OrderHistoryScreen(),
        ),
      );
    });
  }
}

// Top-level background handler (main.dart ke bahar ya alag file mein)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Yahan sirf local notification dikha sakte ho (navigation nahi)
  // Navigation ke liye onMessageOpenedApp ya getInitialMessage use hoga
  await NotificationService()._onForegroundMessage(message); // reuse
}*/

import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:jkautomed/main.dart'; // ajugnuGlobalContext yahan se aata hai

// Agar OrderHistoryScreen ya apne notification screen ka import chahiye to yahan daal dena
// import '../screens/customer_notifications_screen.dart'; // example

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final _messaging = FirebaseMessaging.instance;
  final _localNotifications = FlutterLocalNotificationsPlugin();

  // Yeh flag double navigation rokega
  bool _initialNotificationHandled = false;

  static const _androidChannel = AndroidNotificationChannel(
    'high_importance_channel',
    'High Importance Notifications',
    description: 'Important notifications for Ajugnu',
    importance: Importance.max,
    playSound: true,
  );

  Future<void> initialize() async {
    // Reset flag on every app start (safety)
    _initialNotificationHandled = false;

    // Permissions
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Foreground notification settings
    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // Local notifications initialization
    const initSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettingsIOS = DarwinInitializationSettings();
    const initSettings = InitializationSettings(
      android: initSettingsAndroid,
      iOS: initSettingsIOS,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
      onDidReceiveBackgroundNotificationResponse: _onDidReceiveBackgroundNotificationResponse,
    );

    // Android channel create
    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_androidChannel);

    // 1. App terminated state se launch (notification tap)
    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null && !_initialNotificationHandled) {
      _initialNotificationHandled = true;
      _handleMessage(initialMessage);
    }

    // 2. Background se foreground (notification tap)
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      if (!_initialNotificationHandled) {
        _initialNotificationHandled = true;
        _handleMessage(message);
      }
    });

    // 3. Foreground messages (sirf show karo, navigation mat karo)
    FirebaseMessaging.onMessage.listen(_onForegroundMessage);

    // Background handler register
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  // Foreground message handler
  Future<void> _onForegroundMessage(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;

    await _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _androidChannel.id,
          _androidChannel.name,
          channelDescription: _androidChannel.description,
          importance: _androidChannel.importance,
          icon: '@mipmap/ic_launcher',
        ),
        iOS: const DarwinNotificationDetails(),
      ),
      payload: jsonEncode(message.data), // JSON payload bhej rahe hain
    );
  }

  // Local notification tap (foreground/background)
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    if (response.payload != null && !_initialNotificationHandled) {
      _initialNotificationHandled = true;
      _handlePayload(response.payload!);
    }
  }

  // Background notification tap (killed state)
  @pragma('vm:entry-point')
  static void _onDidReceiveBackgroundNotificationResponse(NotificationResponse response) {
    // Yeh static hona chahiye background ke liye
    if (response.payload != null) {
      // Yahan direct navigation mushkil hai, isliye onMessageOpenedApp par rely karo
      // ya global flag use karo (advanced)
    }
  }

  // Common message handler
  void _handleMessage(RemoteMessage message) {
    _navigateToNotifications(); // Ya apna logic daal do
  }

  // Payload se navigation (local notification ke liye)
  void _handlePayload(String payload) {
    try {
      final data = jsonDecode(payload) as Map<String, dynamic>;
      // Agar screen type check karna ho to yahan kar sakte ho
      _navigateToNotifications();
    } catch (e) {
      debugPrint('Payload parse error: $e');
      _navigateToNotifications(); // default
    }
  }

  // Yeh function apne hisaab se change kar dena
  void _navigateToNotifications() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final context = ajugnuGlobalContext.currentContext;
      if (context == null || !context.mounted) return;

      // Example: Customer notifications screen
      // Navigator.of(context).push(
      //   MaterialPageRoute(builder: (_) => const CustomerNotificationsScreen()),
      // );

      // Ya tumhare AjugnuNavigations class ka use karo
      // AjugnuNavigations.customerNotificationsScreen(onNotificationRead: () {});

      debugPrint("Navigating to notifications screen from tap");
    });
  }
}

// Top-level background handler
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Sirf notification show karo, navigation mat karo
  await NotificationService()._onForegroundMessage(message);
}